Autorka: Bogna Knychała, nr.indeksu 329742


Program można podzielić na następujące części:

1.  Informacje o miejscach pobytu dostępnych w ofercie biura Podróży.
    Miejsca są skategoryzowane na podstawie posiadania lub nieposiadania danej cechy (np. czy jest to miejsce nad wodą)
2.  Opisy miejsc wyświetlane użytkownikowi
3.  Seria pytań, na które można odpowiedzieć tak/nie. Na bazie tych pytań dopasowywana jest proponowana oferta
4.  Część obsługująca działanie program czyli odpowiedzialna za wyświetlanie pytań, uruchomienie całego systemu i pobranie informacji od użytkownika

Użytkownikowi wyświetlana jest seria pytań na temat preferowanych przez niego miejsc wypoczynku.
Odpowiedzi na te pytania mogą być tylko tak lub nie.
Na bazie odpowiedzi dobierana jest odpowiednia miejscowość spełniająca kryteria.
Na końcu wyświetlana jest użytkownikowi krótka informacja na temat tej miejscowości.
Po wczytaniu systemu ekspertowego należy wywołać procedurę main.
