[styczen,luty,marzec,kwiecien,maj,czerwiec,lipiec,sierpien,wrzesien,pazdziernik,listopad,grudzien].

podlista(S,L):-append(L1,L2,L),append(S,L3,L2).

