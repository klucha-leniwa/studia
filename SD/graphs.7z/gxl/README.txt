Small framework for importing/exporting graphs to gxl format.
Thanks to networkx checking two graphs isomorphism is possible.
In future more format might be supported.
Framework is written in python, version 2.7.

Requirments
===========

In order to properly use framework, you need to have the following packages installed
	1. lxml (easy_install lxml) - for parsing xml(gxl) files
	2. networkx (easy_install networkx) - implementation of vl2 algrythm

Author
==========

Bogna Knychała <klucha.leniwa@gmail.com>


